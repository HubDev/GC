(function ($, Drupal, window, document, undefined){

	$(document).ready(function(){


	});

})(jQuery, Drupal, this, this.document);
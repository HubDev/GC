<div class="discover_container">

	<div class="discover_header"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/discover.png' ?>" /></div>

	<div class="dicover_content">
		
		<div class="desc_sidebar">
			<div class="tour_image"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/discover_tab_1.png' ?>" /></div>
			<div class="tour_title">Wonder - The Minotaur (and Mini - Tour) <br /> <span>by Lorem Ipsum</span></div>
			<div class="tour_description_body">Lorem ipsum dolor sit amet, qui ad agam tota sanctus. Cum ne option appetere, quo cu inermis admodum. Ius ne ornatus interesset. Cum cu debet nusquam, vix inermis prodesset constituto in. Te scripta aliquam bonorum vim. suavitate vix, ex facilis appareat principes cum. Ei quo tractatos complectitur, in possit appellantur cum. Te mel mollis aperiam, eu mei ferri graeco, eu suscipit ullamcorper qui.</div>
			<div class="tour_icons"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/tour_desc_icons.png' ?>" /></div>
			
		</div>

		<div class="desc_sidebar">
			<div class="tour_image"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/discover_tab_2.png' ?>" /></div>
			<div class="tour_title">3d ocean farming Saving of the Sea <br /> <span>by Lorem Ipsum</span></div>
			<div class="tour_description_body">Lorem ipsum dolor sit amet, qui ad agam tota sanctus. Cum ne option appetere, quo cu inermis admodum. Ius ne ornatus interesset. Cum cu debet nusquam, vix inermis prodesset constituto in. Te scripta aliquam bonorum vim. suavitate vix, ex facilis appareat principes cum. Ei quo tractatos complectitur, in possit appellantur cum. Te mel mollis aperiam, eu mei ferri graeco, eu suscipit ullamcorper qui.</div>
			<div class="tour_icons"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/tour_desc_icons.png' ?>" /></div>
			
		</div>

		<div class="desc_sidebar">
			<div class="tour_image"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/discover_tab_3.png' ?>" /></div>
			<div class="tour_title">Art exhibit <br /> <span>by Lorem Ipsum</span></div>
			<div class="tour_description_body">Lorem ipsum dolor sit amet, qui ad agam tota sanctus. Cum ne option appetere, quo cu inermis admodum. Ius ne ornatus interesset. Cum cu debet nusquam, vix inermis prodesset constituto in. Te scripta aliquam bonorum vim. suavitate vix, ex facilis appareat principes cum. Ei quo tractatos complectitur, in possit appellantur cum. Te mel mollis aperiam, eu mei ferri graeco, eu suscipit ullamcorper qui.</div>
			<div class="tour_icons"><img src="<?php echo drupal_get_path('theme', 'living_green_2').'/images/tour_desc_icons.png' ?>" /></div>
			
		</div>

	</div>

</div>